package com.sistema.appqrcode.exception;

public class UsuarioNotFoundException {

}
